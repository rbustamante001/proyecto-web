# ALBUM JS

A Pen created on CodePen.

Original URL: [https://codepen.io/RODRIGO-BUSTAMANTE-the-scripter/pen/MYaRdvP](https://codepen.io/RODRIGO-BUSTAMANTE-the-scripter/pen/MYaRdvP).

