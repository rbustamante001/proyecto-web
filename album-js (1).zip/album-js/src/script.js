 //Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://i.pinimg.com/736x/0b/de/ad/0bdeadcfafe84608bd9e2375d39ef05f.jpg",
  "https://i.pinimg.com/736x/2b/2e/43/2b2e43716696947ffd401ff303e09228.jpg",
  "https://i.pinimg.com/736x/96/3b/07/963b07588f00fdd326d7dc293a082ff8.jpg",
  "https://i.pinimg.com/1200x/82/bf/eb/82bfebd3a15a6c9142106436bdcca668.jpg",
  "https://i.pinimg.com/736x/e2/6b/aa/e26baa15dfedc9b0f7f8c4acae2cc93f.jpg",
  
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});