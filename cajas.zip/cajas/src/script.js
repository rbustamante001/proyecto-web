// Cambiar el título
document.getElementById("btn-titulo").addEventListener("click", () => {
  const titulo = document.getElementById("titulo");
  titulo.textContent = "¡Rodrigo Bustamante!";
});

// Cambiar color de todas las cajas
document.getElementById("btn-cajas").addEventListener("click", () => {
  const cajas = document.getElementsByClassName("caja");
  for (let i = 0; i < cajas.length; i++) {
    cajas[i].style.backgroundColor = "pink"; // rosa clarito
  }
});

// Cambiar color solo de la primera caja
document.getElementById("btn-primera").addEventListener("click", () => {
  const primeracaja = document.querySelector(".caja");
  primeracaja.style.backgroundColor = "green"; // verde
});

// Cambiar borde de todas las cajas
document.getElementById("btn-bordes").addEventListener("click", () => {
  const cajas = document.querySelectorAll(".caja");
  cajas.forEach(caja => {
    caja.style.border = "3px solid red"; // borde rojo
  });
});